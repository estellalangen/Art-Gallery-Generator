// Student Name: Estella Langenhoven
// Student ID: 21030873 

let myButton; 
let myHead;
let tempNumb;
let tempColour;
let canvasColour1;
let canvasColour2;
let canvasColour3;
let numberLibrary = [];
let colourLibrary = [];

function setup() {
	createCanvas(400, 400);
	background(200);
	splashScreen();
	myHead = createElement("h1", "Press the button to generate art!");
	myButton = createButton("Generate Art");
	myButton.mousePressed(artGenerate);
}

function keyPressed() {
	artGenerate();
}

function artGenerate() {
	canvasColour1 = (random(0, 255));
	canvasColour2 = (random(0, 255));
	canvasColour3 = (random(0, 255));
	background(canvasColour1, canvasColour2, canvasColour3);
	
	for (let i = 0; i<=7; i++) {
		tempNumb = random(0, 400);
		numberLibrary [i] = tempNumb;
	}
	
	for (let i = 0; i<=3; i++) {
		tempColour = random(0, 255);
		colourLibrary [i] = tempColour;
	}
	noStroke();
	fill(numberLibrary[0], numberLibrary[1], numberLibrary[2]);
	
	beginShape();
		vertex(numberLibrary[0], numberLibrary[1]);
		vertex(numberLibrary[2], numberLibrary[3]);
		vertex(numberLibrary[4], numberLibrary[5]);
		vertex(numberLibrary[6], numberLibrary[7]);
	endShape(CLOSE);
}

function splashScreen() {
	background(120, 15, 19);
	stroke(255);
	fill(255);
	textFont('Comic Sans MS');
	textSize(27);
	text("Welcome to the art gallery <3", 15, 150);
	
}
	